const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const dataToDb = require('./utils/dataToDb')

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const port = process.env.port || 1145;

app.post('/api/createTask', (req, res) => {
  console.log(req.body);
  res.send('create');
  dataToDb(req.body);
});

app.delete('/api/deleteTask', (req, res) =>{
    res.send('delete');
    // remove the item from DB
})
app.listen(port, () =>{
    console.log(`server up listening on ${port}`);
})