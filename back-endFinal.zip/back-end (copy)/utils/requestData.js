const dbPipeline = require('./dataToDb')

function destructureRequestData(dataToDestruct) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const { title, Content } = dataToDestruct;
        // send this to db
        // create a function that transports this to the db section. 
        // it will act as a pipe line
        dbPipeline(dataToDestruct)
        resolve({
          title,
          Content
        });
      }, 1000); // Simulating asynchronous operation with a delay of 1 second
    });
  }
  
  module.exports = destructureRequestData;
  