const mongoose = require('mongoose');

// Function to save data to the database
function saveDataToDb(data) {
    // Data Base Connection

  mongoose.connect('mongodb://localhost:27017/ToDoList', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to the database');
  })
  .catch(error => {
    console.error('Failed to connect to the database:', error);
  });

// Setting up the DB Schema
const dbSchema = new mongoose.Schema({
  title: String,
  content: String
});

// Creating a collection
const todoItem = mongoose.model("todoItems", dbSchema);
  const { title, Content } = data;
  
  const newItem = new todoItem({
    title: title,
    content: Content
  });

  newItem.save()
    .then(() => {
      console.log('Data saved to the database:', newItem);
    })
    .catch(error => {
      console.error('Failed to save data to the database:', error);
    });
}

module.exports = saveDataToDb;
