const mongoose = require('mongoose');

// Function to delete data from the database
function deleteDataToDb(data) {
  // Data Base Connection
  mongoose.connect('mongodb://localhost:27017/ToDoList', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
      console.log('Connected to the database');
      
      // Setting up the DB Schema
      const dbSchema = new mongoose.Schema({
        title: String,
        content: String
      });

      // Creating a collection
      const todoItem = mongoose.model("todoItems", dbSchema);

      // Deleting data based on title
      todoItem.deleteMany({ title: data.title })
        .then(result => {
          console.log('Data deleted from the database:', result);
        })
        .catch(error => {
          console.error('Failed to delete data from the database:', error);
        })
        .finally(() => {
          mongoose.disconnect(); // Disconnect from the database after deleting data
        });
    })
    .catch(error => {
      console.error('Failed to connect to the database:', error);
    });
}

module.exports = deleteDataToDb;
